
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/coinEffect.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '226ecyKWwRHmIvme3HG/Gmq', 'coinEffect');
// scripts/coinEffect.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoinEffect = void 0;
var flyItem_1 = require("./flyItem");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
// 金币飞行特效
var CoinEffect = /** @class */ (function (_super) {
    __extends(CoinEffect, _super);
    function CoinEffect() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.btn = null;
        _this.target = null;
        _this.num = 0;
        _this.item = null;
        _this.list = [];
        return _this;
    }
    CoinEffect.prototype.start = function () {
        this.btn.on('click', this.starEffect, this);
    };
    CoinEffect.prototype.starEffect = function () {
        var _this = this;
        for (var i = 0; i < this.num; i++) {
            var item = this.list[i];
            if (!item) {
                item = cc.instantiate(this.item);
                item.parent = this.node;
                this.list.push(item);
            }
        }
        this.list.forEach(function (value) {
            var fiyItem = value.getComponent(flyItem_1.flyItem);
            fiyItem.initFly(new cc.Vec3(0, 0), _this.target.position);
            fiyItem.starFly();
        });
    };
    __decorate([
        property(cc.Node)
    ], CoinEffect.prototype, "btn", void 0);
    __decorate([
        property(cc.Node)
    ], CoinEffect.prototype, "target", void 0);
    __decorate([
        property()
    ], CoinEffect.prototype, "num", void 0);
    __decorate([
        property(cc.Prefab)
    ], CoinEffect.prototype, "item", void 0);
    CoinEffect = __decorate([
        ccclass
    ], CoinEffect);
    return CoinEffect;
}(cc.Component));
exports.CoinEffect = CoinEffect;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcY29pbkVmZmVjdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEscUNBQW9DO0FBRTlCLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBQzVDLFNBQVM7QUFFVDtJQUFnQyw4QkFBWTtJQUE1QztRQUFBLHFFQXVDQztRQXBDYSxTQUFHLEdBQVksSUFBSSxDQUFDO1FBRXBCLFlBQU0sR0FBWSxJQUFJLENBQUE7UUFHeEIsU0FBRyxHQUFXLENBQUMsQ0FBQztRQUdkLFVBQUksR0FBYyxJQUFJLENBQUM7UUFFekIsVUFBSSxHQUFjLEVBQUUsQ0FBQTs7SUEwQmhDLENBQUM7SUF2QkcsMEJBQUssR0FBTDtRQUNJLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxDQUFBO0lBQy9DLENBQUM7SUFHRCwrQkFBVSxHQUFWO1FBQUEsaUJBZ0JDO1FBZkcsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFFL0IsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN4QixJQUFJLENBQUMsSUFBSSxFQUFFO2dCQUNQLElBQUksR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDakMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO2dCQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQTthQUN2QjtTQUNKO1FBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBQyxLQUFLO1lBQ3BCLElBQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUMsaUJBQU8sQ0FBQyxDQUFDO1lBQzVDLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxLQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3pELE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUN0QixDQUFDLENBQUMsQ0FBQTtJQUVOLENBQUM7SUFsQ0Q7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzsyQ0FDWTtJQUU5QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDOzhDQUNjO0lBR2hDO1FBREMsUUFBUSxFQUFFOzJDQUNhO0lBR3hCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7NENBQ2E7SUFYeEIsVUFBVTtRQUR0QixPQUFPO09BQ0ssVUFBVSxDQXVDdEI7SUFBRCxpQkFBQztDQXZDRCxBQXVDQyxDQXZDK0IsRUFBRSxDQUFDLFNBQVMsR0F1QzNDO0FBdkNZLGdDQUFVIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZmx5SXRlbSB9IGZyb20gXCIuL2ZseUl0ZW1cIjtcclxuXHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XHJcbi8vIOmHkeW4gemjnuihjOeJueaViFxyXG5AY2NjbGFzc1xyXG5leHBvcnQgY2xhc3MgQ29pbkVmZmVjdCBleHRlbmRzIGNjLkNvbXBvbmVudCB7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBwcm90ZWN0ZWQgYnRuOiBjYy5Ob2RlID0gbnVsbDtcclxuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxyXG4gICAgcHJvdGVjdGVkIHRhcmdldDogY2MuTm9kZSA9IG51bGxcclxuXHJcbiAgICBAcHJvcGVydHkoKVxyXG4gICAgcHJpdmF0ZSBudW06IG51bWJlciA9IDA7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLlByZWZhYilcclxuICAgIHByb3RlY3RlZCBpdGVtOiBjYy5QcmVmYWIgPSBudWxsO1xyXG5cclxuICAgIHByaXZhdGUgbGlzdDogY2MuTm9kZVtdID0gW11cclxuXHJcblxyXG4gICAgc3RhcnQoKSB7XHJcbiAgICAgICAgdGhpcy5idG4ub24oJ2NsaWNrJywgdGhpcy5zdGFyRWZmZWN0LCB0aGlzKVxyXG4gICAgfVxyXG5cclxuXHJcbiAgICBzdGFyRWZmZWN0KCkge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5udW07IGkrKykge1xyXG5cclxuICAgICAgICAgICAgbGV0IGl0ZW0gPSB0aGlzLmxpc3RbaV07XHJcbiAgICAgICAgICAgIGlmICghaXRlbSkge1xyXG4gICAgICAgICAgICAgICAgaXRlbSA9IGNjLmluc3RhbnRpYXRlKHRoaXMuaXRlbSk7XHJcbiAgICAgICAgICAgICAgICBpdGVtLnBhcmVudCA9IHRoaXMubm9kZTtcclxuICAgICAgICAgICAgICAgIHRoaXMubGlzdC5wdXNoKGl0ZW0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5saXN0LmZvckVhY2goKHZhbHVlKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IGZpeUl0ZW0gPSB2YWx1ZS5nZXRDb21wb25lbnQoZmx5SXRlbSk7XHJcbiAgICAgICAgICAgIGZpeUl0ZW0uaW5pdEZseShuZXcgY2MuVmVjMygwLCAwKSwgdGhpcy50YXJnZXQucG9zaXRpb24pO1xyXG4gICAgICAgICAgICBmaXlJdGVtLnN0YXJGbHkoKTtcclxuICAgICAgICB9KVxyXG5cclxuICAgIH1cclxuXHJcbn1cclxuIl19