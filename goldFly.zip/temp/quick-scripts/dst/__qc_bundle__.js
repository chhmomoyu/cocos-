
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/scripts/coinEffect');
require('./assets/scripts/flyItem');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/coinEffect.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '226ecyKWwRHmIvme3HG/Gmq', 'coinEffect');
// scripts/coinEffect.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoinEffect = void 0;
var flyItem_1 = require("./flyItem");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
// 金币飞行特效
var CoinEffect = /** @class */ (function (_super) {
    __extends(CoinEffect, _super);
    function CoinEffect() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.btn = null;
        _this.target = null;
        _this.num = 0;
        _this.item = null;
        _this.list = [];
        return _this;
    }
    CoinEffect.prototype.start = function () {
        this.btn.on('click', this.starEffect, this);
    };
    CoinEffect.prototype.starEffect = function () {
        var _this = this;
        for (var i = 0; i < this.num; i++) {
            var item = this.list[i];
            if (!item) {
                item = cc.instantiate(this.item);
                item.parent = this.node;
                this.list.push(item);
            }
        }
        this.list.forEach(function (value) {
            var fiyItem = value.getComponent(flyItem_1.flyItem);
            fiyItem.initFly(new cc.Vec3(0, 0), _this.target.position);
            fiyItem.starFly();
        });
    };
    __decorate([
        property(cc.Node)
    ], CoinEffect.prototype, "btn", void 0);
    __decorate([
        property(cc.Node)
    ], CoinEffect.prototype, "target", void 0);
    __decorate([
        property()
    ], CoinEffect.prototype, "num", void 0);
    __decorate([
        property(cc.Prefab)
    ], CoinEffect.prototype, "item", void 0);
    CoinEffect = __decorate([
        ccclass
    ], CoinEffect);
    return CoinEffect;
}(cc.Component));
exports.CoinEffect = CoinEffect;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcY29pbkVmZmVjdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEscUNBQW9DO0FBRTlCLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBQzVDLFNBQVM7QUFFVDtJQUFnQyw4QkFBWTtJQUE1QztRQUFBLHFFQXVDQztRQXBDYSxTQUFHLEdBQVksSUFBSSxDQUFDO1FBRXBCLFlBQU0sR0FBWSxJQUFJLENBQUE7UUFHeEIsU0FBRyxHQUFXLENBQUMsQ0FBQztRQUdkLFVBQUksR0FBYyxJQUFJLENBQUM7UUFFekIsVUFBSSxHQUFjLEVBQUUsQ0FBQTs7SUEwQmhDLENBQUM7SUF2QkcsMEJBQUssR0FBTDtRQUNJLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxDQUFBO0lBQy9DLENBQUM7SUFHRCwrQkFBVSxHQUFWO1FBQUEsaUJBZ0JDO1FBZkcsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFFL0IsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN4QixJQUFJLENBQUMsSUFBSSxFQUFFO2dCQUNQLElBQUksR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDakMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO2dCQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQTthQUN2QjtTQUNKO1FBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBQyxLQUFLO1lBQ3BCLElBQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUMsaUJBQU8sQ0FBQyxDQUFDO1lBQzVDLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxLQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3pELE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUN0QixDQUFDLENBQUMsQ0FBQTtJQUVOLENBQUM7SUFsQ0Q7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzsyQ0FDWTtJQUU5QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDOzhDQUNjO0lBR2hDO1FBREMsUUFBUSxFQUFFOzJDQUNhO0lBR3hCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7NENBQ2E7SUFYeEIsVUFBVTtRQUR0QixPQUFPO09BQ0ssVUFBVSxDQXVDdEI7SUFBRCxpQkFBQztDQXZDRCxBQXVDQyxDQXZDK0IsRUFBRSxDQUFDLFNBQVMsR0F1QzNDO0FBdkNZLGdDQUFVIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZmx5SXRlbSB9IGZyb20gXCIuL2ZseUl0ZW1cIjtcclxuXHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XHJcbi8vIOmHkeW4gemjnuihjOeJueaViFxyXG5AY2NjbGFzc1xyXG5leHBvcnQgY2xhc3MgQ29pbkVmZmVjdCBleHRlbmRzIGNjLkNvbXBvbmVudCB7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBwcm90ZWN0ZWQgYnRuOiBjYy5Ob2RlID0gbnVsbDtcclxuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxyXG4gICAgcHJvdGVjdGVkIHRhcmdldDogY2MuTm9kZSA9IG51bGxcclxuXHJcbiAgICBAcHJvcGVydHkoKVxyXG4gICAgcHJpdmF0ZSBudW06IG51bWJlciA9IDA7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLlByZWZhYilcclxuICAgIHByb3RlY3RlZCBpdGVtOiBjYy5QcmVmYWIgPSBudWxsO1xyXG5cclxuICAgIHByaXZhdGUgbGlzdDogY2MuTm9kZVtdID0gW11cclxuXHJcblxyXG4gICAgc3RhcnQoKSB7XHJcbiAgICAgICAgdGhpcy5idG4ub24oJ2NsaWNrJywgdGhpcy5zdGFyRWZmZWN0LCB0aGlzKVxyXG4gICAgfVxyXG5cclxuXHJcbiAgICBzdGFyRWZmZWN0KCkge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5udW07IGkrKykge1xyXG5cclxuICAgICAgICAgICAgbGV0IGl0ZW0gPSB0aGlzLmxpc3RbaV07XHJcbiAgICAgICAgICAgIGlmICghaXRlbSkge1xyXG4gICAgICAgICAgICAgICAgaXRlbSA9IGNjLmluc3RhbnRpYXRlKHRoaXMuaXRlbSk7XHJcbiAgICAgICAgICAgICAgICBpdGVtLnBhcmVudCA9IHRoaXMubm9kZTtcclxuICAgICAgICAgICAgICAgIHRoaXMubGlzdC5wdXNoKGl0ZW0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5saXN0LmZvckVhY2goKHZhbHVlKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IGZpeUl0ZW0gPSB2YWx1ZS5nZXRDb21wb25lbnQoZmx5SXRlbSk7XHJcbiAgICAgICAgICAgIGZpeUl0ZW0uaW5pdEZseShuZXcgY2MuVmVjMygwLCAwKSwgdGhpcy50YXJnZXQucG9zaXRpb24pO1xyXG4gICAgICAgICAgICBmaXlJdGVtLnN0YXJGbHkoKTtcclxuICAgICAgICB9KVxyXG5cclxuICAgIH1cclxuXHJcbn1cclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/flyItem.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '42c1dy8JG9A2YUuH7/2WjFk', 'flyItem');
// scripts/flyItem.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.flyItem = void 0;
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
// 飞行物品预制体
var flyItem = /** @class */ (function (_super) {
    __extends(flyItem, _super);
    function flyItem() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // 图标
        _this.sp = null;
        _this.explodeSpeel = 0;
        _this.moveSpell = 0;
        return _this;
    }
    flyItem.prototype.initFly = function (starPostion, endPosition) {
        this._startPosition = starPostion;
        this._endPosition = endPosition;
        this.node.setPosition(starPostion);
    };
    flyItem.prototype.starFly = function () {
        // 爆炸开
        this.explodeFly();
        this.flyTarget();
    };
    flyItem.prototype.explodeFly = function () {
        var randowX = Math.random() * 100;
        var randowY = Math.random() * 100;
        var target = new cc.Vec3(randowX, randowY);
        cc.log('随机生成爆炸坐标', target);
        this._explodetime = this.node.position.sub(target).mag() / this.explodeSpeel;
        cc.tween(this.node)
            .to(0, { opacity: 255 })
            .to(this._explodetime, { position: target })
            .start();
    };
    flyItem.prototype.flyTarget = function () {
        // 随机生成控制点的偏移量
        var offsetX1 = Math.random() * 200; // 偏移范围可以根据需求调整
        var offsetY1 = Math.random() * 200; // 向上或向下的偏移
        var offsetX2 = Math.random() * 200 - 80; // 偏移范围可以根据需求调整
        var offsetY2 = Math.random() * 200; // 向上或向下的偏移
        var controlPoint1 = new cc.Vec2(this.node.position.x + offsetX1, this.node.position.y + offsetY1);
        var controlPoint2 = new cc.Vec2(this._endPosition.x + offsetX2, this._endPosition.y + offsetY2);
        var time = this.node.position.sub(this._endPosition).mag() / this.moveSpell;
        cc.tween(this.node)
            .delay(this._explodetime + 0.2)
            // .to(time, { position: this._endPosition })
            .bezierTo(time, controlPoint1, controlPoint2, cc.v2(this._endPosition))
            .to(time, { opacity: 0 })
            .start();
    };
    __decorate([
        property(cc.Sprite)
    ], flyItem.prototype, "sp", void 0);
    __decorate([
        property()
    ], flyItem.prototype, "explodeSpeel", void 0);
    __decorate([
        property()
    ], flyItem.prototype, "moveSpell", void 0);
    flyItem = __decorate([
        ccclass
    ], flyItem);
    return flyItem;
}(cc.Component));
exports.flyItem = flyItem;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcZmx5SXRlbS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ00sSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFDNUMsVUFBVTtBQUVWO0lBQTZCLDJCQUFZO0lBQXpDO1FBQUEscUVBcUVDO1FBcEVHLEtBQUs7UUFFSyxRQUFFLEdBQWMsSUFBSSxDQUFDO1FBR3JCLGtCQUFZLEdBQVcsQ0FBQyxDQUFDO1FBRXpCLGVBQVMsR0FBVyxDQUFDLENBQUM7O0lBNkRwQyxDQUFDO0lBbkRVLHlCQUFPLEdBQWQsVUFBZSxXQUFvQixFQUFFLFdBQW9CO1FBQ3JELElBQUksQ0FBQyxjQUFjLEdBQUcsV0FBVyxDQUFDO1FBQ2xDLElBQUksQ0FBQyxZQUFZLEdBQUcsV0FBVyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFBO0lBQ3RDLENBQUM7SUFFTSx5QkFBTyxHQUFkO1FBQ0ksTUFBTTtRQUNOLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7SUFFckIsQ0FBQztJQUVNLDRCQUFVLEdBQWpCO1FBQ0ksSUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQztRQUNwQyxJQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDO1FBQ3BDLElBQU0sTUFBTSxHQUFHLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDN0MsRUFBRSxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLENBQUE7UUFDMUIsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQTtRQUM1RSxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7YUFDZCxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDO2FBQ3ZCLEVBQUUsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxDQUFDO2FBQzNDLEtBQUssRUFBRSxDQUFDO0lBQ2pCLENBQUM7SUFFTSwyQkFBUyxHQUFoQjtRQUNJLGNBQWM7UUFDZCxJQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLENBQUMsZUFBZTtRQUNyRCxJQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLENBQUMsV0FBVztRQUVqRCxJQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsR0FBRyxHQUFHLEVBQUUsQ0FBQyxDQUFDLGVBQWU7UUFDMUQsSUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxDQUFDLFdBQVc7UUFFakQsSUFBTSxhQUFhLEdBQUcsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUM3QixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsUUFBUSxFQUMvQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsUUFBUSxDQUNsQyxDQUFDO1FBQ0YsSUFBTSxhQUFhLEdBQUcsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUM3QixJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsR0FBRyxRQUFRLEVBQzlCLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FDakMsQ0FBQztRQUNGLElBQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQTtRQUM3RSxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7YUFDZCxLQUFLLENBQUMsSUFBSSxDQUFDLFlBQVksR0FBRyxHQUFHLENBQUM7WUFDL0IsNkNBQTZDO2FBQzVDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsYUFBYSxFQUFFLGFBQWEsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQzthQUN0RSxFQUFFLENBQUMsSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDO2FBRXhCLEtBQUssRUFBRSxDQUFDO0lBQ2pCLENBQUM7SUFoRUQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQzt1Q0FDVztJQUcvQjtRQURDLFFBQVEsRUFBRTtpREFDd0I7SUFFbkM7UUFEQyxRQUFRLEVBQUU7OENBQ3FCO0lBUnZCLE9BQU87UUFEbkIsT0FBTztPQUNLLE9BQU8sQ0FxRW5CO0lBQUQsY0FBQztDQXJFRCxBQXFFQyxDQXJFNEIsRUFBRSxDQUFDLFNBQVMsR0FxRXhDO0FBckVZLDBCQUFPIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XHJcbi8vIOmjnuihjOeJqeWTgemihOWItuS9k1xyXG5AY2NjbGFzc1xyXG5leHBvcnQgY2xhc3MgZmx5SXRlbSBleHRlbmRzIGNjLkNvbXBvbmVudCB7XHJcbiAgICAvLyDlm77moIdcclxuICAgIEBwcm9wZXJ0eShjYy5TcHJpdGUpXHJcbiAgICBwcm90ZWN0ZWQgc3A6IGNjLlNwcml0ZSA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KClcclxuICAgIHByb3RlY3RlZCBleHBsb2RlU3BlZWw6IG51bWJlciA9IDA7XHJcbiAgICBAcHJvcGVydHkoKVxyXG4gICAgcHJvdGVjdGVkIG1vdmVTcGVsbDogbnVtYmVyID0gMDtcclxuXHJcblxyXG4gICAgLy8g5Yid5aeL5L2N572uXHJcbiAgICBwcml2YXRlIF9zdGFydFBvc2l0aW9uOiBjYy5WZWMzO1xyXG4gICAgLy8g57uT5p2f5L2N572uXHJcbiAgICBwcml2YXRlIF9lbmRQb3NpdGlvbjogY2MuVmVjMztcclxuICAgIC8vXHJcbiAgICBwcml2YXRlIF9leHBsb2RldGltZTogbnVtYmVyXHJcblxyXG4gICAgcHVibGljIGluaXRGbHkoc3RhclBvc3Rpb246IGNjLlZlYzMsIGVuZFBvc2l0aW9uOiBjYy5WZWMzKSB7XHJcbiAgICAgICAgdGhpcy5fc3RhcnRQb3NpdGlvbiA9IHN0YXJQb3N0aW9uO1xyXG4gICAgICAgIHRoaXMuX2VuZFBvc2l0aW9uID0gZW5kUG9zaXRpb247XHJcbiAgICAgICAgdGhpcy5ub2RlLnNldFBvc2l0aW9uKHN0YXJQb3N0aW9uKVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzdGFyRmx5KCkge1xyXG4gICAgICAgIC8vIOeIhueCuOW8gFxyXG4gICAgICAgIHRoaXMuZXhwbG9kZUZseSgpO1xyXG4gICAgICAgIHRoaXMuZmx5VGFyZ2V0KCk7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBleHBsb2RlRmx5KCkge1xyXG4gICAgICAgIGNvbnN0IHJhbmRvd1ggPSBNYXRoLnJhbmRvbSgpICogMTAwO1xyXG4gICAgICAgIGNvbnN0IHJhbmRvd1kgPSBNYXRoLnJhbmRvbSgpICogMTAwO1xyXG4gICAgICAgIGNvbnN0IHRhcmdldCA9IG5ldyBjYy5WZWMzKHJhbmRvd1gsIHJhbmRvd1kpO1xyXG4gICAgICAgIGNjLmxvZygn6ZqP5py655Sf5oiQ54iG54K45Z2Q5qCHJywgdGFyZ2V0KVxyXG4gICAgICAgIHRoaXMuX2V4cGxvZGV0aW1lID0gdGhpcy5ub2RlLnBvc2l0aW9uLnN1Yih0YXJnZXQpLm1hZygpIC8gdGhpcy5leHBsb2RlU3BlZWxcclxuICAgICAgICBjYy50d2Vlbih0aGlzLm5vZGUpXHJcbiAgICAgICAgICAgIC50bygwLCB7IG9wYWNpdHk6IDI1NSB9KVxyXG4gICAgICAgICAgICAudG8odGhpcy5fZXhwbG9kZXRpbWUsIHsgcG9zaXRpb246IHRhcmdldCB9KVxyXG4gICAgICAgICAgICAuc3RhcnQoKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZmx5VGFyZ2V0KCkge1xyXG4gICAgICAgIC8vIOmaj+acuueUn+aIkOaOp+WItueCueeahOWBj+enu+mHj1xyXG4gICAgICAgIGNvbnN0IG9mZnNldFgxID0gTWF0aC5yYW5kb20oKSAqIDIwMDsgLy8g5YGP56e76IyD5Zu05Y+v5Lul5qC55o2u6ZyA5rGC6LCD5pW0XHJcbiAgICAgICAgY29uc3Qgb2Zmc2V0WTEgPSBNYXRoLnJhbmRvbSgpICogMjAwOyAvLyDlkJHkuIrmiJblkJHkuIvnmoTlgY/np7tcclxuXHJcbiAgICAgICAgY29uc3Qgb2Zmc2V0WDIgPSBNYXRoLnJhbmRvbSgpICogMjAwIC0gODA7IC8vIOWBj+enu+iMg+WbtOWPr+S7peagueaNrumcgOaxguiwg+aVtFxyXG4gICAgICAgIGNvbnN0IG9mZnNldFkyID0gTWF0aC5yYW5kb20oKSAqIDIwMDsgLy8g5ZCR5LiK5oiW5ZCR5LiL55qE5YGP56e7XHJcblxyXG4gICAgICAgIGNvbnN0IGNvbnRyb2xQb2ludDEgPSBuZXcgY2MuVmVjMihcclxuICAgICAgICAgICAgdGhpcy5ub2RlLnBvc2l0aW9uLnggKyBvZmZzZXRYMSxcclxuICAgICAgICAgICAgdGhpcy5ub2RlLnBvc2l0aW9uLnkgKyBvZmZzZXRZMVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgY29uc3QgY29udHJvbFBvaW50MiA9IG5ldyBjYy5WZWMyKFxyXG4gICAgICAgICAgICB0aGlzLl9lbmRQb3NpdGlvbi54ICsgb2Zmc2V0WDIsXHJcbiAgICAgICAgICAgIHRoaXMuX2VuZFBvc2l0aW9uLnkgKyBvZmZzZXRZMlxyXG4gICAgICAgICk7XHJcbiAgICAgICAgY29uc3QgdGltZSA9IHRoaXMubm9kZS5wb3NpdGlvbi5zdWIodGhpcy5fZW5kUG9zaXRpb24pLm1hZygpIC8gdGhpcy5tb3ZlU3BlbGxcclxuICAgICAgICBjYy50d2Vlbih0aGlzLm5vZGUpXHJcbiAgICAgICAgICAgIC5kZWxheSh0aGlzLl9leHBsb2RldGltZSArIDAuMilcclxuICAgICAgICAgICAgLy8gLnRvKHRpbWUsIHsgcG9zaXRpb246IHRoaXMuX2VuZFBvc2l0aW9uIH0pXHJcbiAgICAgICAgICAgIC5iZXppZXJUbyh0aW1lLCBjb250cm9sUG9pbnQxLCBjb250cm9sUG9pbnQyLCBjYy52Mih0aGlzLl9lbmRQb3NpdGlvbikpXHJcbiAgICAgICAgICAgIC50byh0aW1lLCB7IG9wYWNpdHk6IDAgfSlcclxuXHJcbiAgICAgICAgICAgIC5zdGFydCgpO1xyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=
//------QC-SOURCE-SPLIT------
