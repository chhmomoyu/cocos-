
require('./assets/scripts/coinEffect');
require('./assets/scripts/flyItem');
