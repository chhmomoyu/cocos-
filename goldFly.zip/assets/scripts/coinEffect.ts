import { flyItem } from "./flyItem";

const { ccclass, property } = cc._decorator;
// 金币飞行特效
@ccclass
export class CoinEffect extends cc.Component {

    @property(cc.Node)
    protected btn: cc.Node = null;
    @property(cc.Node)
    protected target: cc.Node = null

    @property()
    private num: number = 0;

    @property(cc.Prefab)
    protected item: cc.Prefab = null;

    private list: cc.Node[] = []


    start() {
        this.btn.on('click', this.starEffect, this)
    }


    starEffect() {
        for (let i = 0; i < this.num; i++) {

            let item = this.list[i];
            if (!item) {
                item = cc.instantiate(this.item);
                item.parent = this.node;
                this.list.push(item)
            }
        }
        this.list.forEach((value) => {
            const fiyItem = value.getComponent(flyItem);
            fiyItem.initFly(new cc.Vec3(0, 0), this.target.position);
            fiyItem.starFly();
        })

    }

}
