
const { ccclass, property } = cc._decorator;
// 飞行物品预制体
@ccclass
export class flyItem extends cc.Component {
    // 图标
    @property(cc.Sprite)
    protected sp: cc.Sprite = null;

    @property()
    protected explodeSpeel: number = 0;
    @property()
    protected moveSpell: number = 0;


    // 初始位置
    private _startPosition: cc.Vec3;
    // 结束位置
    private _endPosition: cc.Vec3;
    //
    private _explodetime: number

    public initFly(starPostion: cc.Vec3, endPosition: cc.Vec3) {
        this._startPosition = starPostion;
        this._endPosition = endPosition;
        this.node.setPosition(starPostion)
    }

    public starFly() {
        // 爆炸开
        this.explodeFly();
        this.flyTarget();

    }

    public explodeFly() {
        const randowX = Math.random() * 100;
        const randowY = Math.random() * 100;
        const target = new cc.Vec3(randowX, randowY);
        cc.log('随机生成爆炸坐标', target)
        this._explodetime = this.node.position.sub(target).mag() / this.explodeSpeel
        cc.tween(this.node)
            .to(0, { opacity: 255 })
            .to(this._explodetime, { position: target })
            .start();
    }

    public flyTarget() {
        // 随机生成控制点的偏移量
        const offsetX1 = Math.random() * 200; // 偏移范围可以根据需求调整
        const offsetY1 = Math.random() * 200; // 向上或向下的偏移

        const offsetX2 = Math.random() * 200 - 80; // 偏移范围可以根据需求调整
        const offsetY2 = Math.random() * 200; // 向上或向下的偏移

        const controlPoint1 = new cc.Vec2(
            this.node.position.x + offsetX1,
            this.node.position.y + offsetY1
        );
        const controlPoint2 = new cc.Vec2(
            this._endPosition.x + offsetX2,
            this._endPosition.y + offsetY2
        );
        const time = this.node.position.sub(this._endPosition).mag() / this.moveSpell
        cc.tween(this.node)
            .delay(this._explodetime + 0.2)
            // .to(time, { position: this._endPosition })
            .bezierTo(time, controlPoint1, controlPoint2, cc.v2(this._endPosition))
            .to(time, { opacity: 0 })

            .start();
    }

}
