"use strict";
cc._RF.push(module, '42c1dy8JG9A2YUuH7/2WjFk', 'flyItem');
// scripts/flyItem.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.flyItem = void 0;
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
// 飞行物品预制体
var flyItem = /** @class */ (function (_super) {
    __extends(flyItem, _super);
    function flyItem() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // 图标
        _this.sp = null;
        _this.explodeSpeel = 0;
        _this.moveSpell = 0;
        return _this;
    }
    flyItem.prototype.initFly = function (starPostion, endPosition) {
        this._startPosition = starPostion;
        this._endPosition = endPosition;
        this.node.setPosition(starPostion);
    };
    flyItem.prototype.starFly = function () {
        // 爆炸开
        this.explodeFly();
        this.flyTarget();
    };
    flyItem.prototype.explodeFly = function () {
        var randowX = Math.random() * 100;
        var randowY = Math.random() * 100;
        var target = new cc.Vec3(randowX, randowY);
        cc.log('随机生成爆炸坐标', target);
        this._explodetime = this.node.position.sub(target).mag() / this.explodeSpeel;
        cc.tween(this.node)
            .to(0, { opacity: 255 })
            .to(this._explodetime, { position: target })
            .start();
    };
    flyItem.prototype.flyTarget = function () {
        // 随机生成控制点的偏移量
        var offsetX1 = Math.random() * 200; // 偏移范围可以根据需求调整
        var offsetY1 = Math.random() * 200; // 向上或向下的偏移
        var offsetX2 = Math.random() * 200 - 80; // 偏移范围可以根据需求调整
        var offsetY2 = Math.random() * 200; // 向上或向下的偏移
        var controlPoint1 = new cc.Vec2(this.node.position.x + offsetX1, this.node.position.y + offsetY1);
        var controlPoint2 = new cc.Vec2(this._endPosition.x + offsetX2, this._endPosition.y + offsetY2);
        var time = this.node.position.sub(this._endPosition).mag() / this.moveSpell;
        cc.tween(this.node)
            .delay(this._explodetime + 0.2)
            // .to(time, { position: this._endPosition })
            .bezierTo(time, controlPoint1, controlPoint2, cc.v2(this._endPosition))
            .to(time, { opacity: 0 })
            .start();
    };
    __decorate([
        property(cc.Sprite)
    ], flyItem.prototype, "sp", void 0);
    __decorate([
        property()
    ], flyItem.prototype, "explodeSpeel", void 0);
    __decorate([
        property()
    ], flyItem.prototype, "moveSpell", void 0);
    flyItem = __decorate([
        ccclass
    ], flyItem);
    return flyItem;
}(cc.Component));
exports.flyItem = flyItem;

cc._RF.pop();