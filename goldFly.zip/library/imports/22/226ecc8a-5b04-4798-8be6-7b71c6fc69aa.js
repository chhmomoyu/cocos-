"use strict";
cc._RF.push(module, '226ecyKWwRHmIvme3HG/Gmq', 'coinEffect');
// scripts/coinEffect.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoinEffect = void 0;
var flyItem_1 = require("./flyItem");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
// 金币飞行特效
var CoinEffect = /** @class */ (function (_super) {
    __extends(CoinEffect, _super);
    function CoinEffect() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.btn = null;
        _this.target = null;
        _this.num = 0;
        _this.item = null;
        _this.list = [];
        return _this;
    }
    CoinEffect.prototype.start = function () {
        this.btn.on('click', this.starEffect, this);
    };
    CoinEffect.prototype.starEffect = function () {
        var _this = this;
        for (var i = 0; i < this.num; i++) {
            var item = this.list[i];
            if (!item) {
                item = cc.instantiate(this.item);
                item.parent = this.node;
                this.list.push(item);
            }
        }
        this.list.forEach(function (value) {
            var fiyItem = value.getComponent(flyItem_1.flyItem);
            fiyItem.initFly(new cc.Vec3(0, 0), _this.target.position);
            fiyItem.starFly();
        });
    };
    __decorate([
        property(cc.Node)
    ], CoinEffect.prototype, "btn", void 0);
    __decorate([
        property(cc.Node)
    ], CoinEffect.prototype, "target", void 0);
    __decorate([
        property()
    ], CoinEffect.prototype, "num", void 0);
    __decorate([
        property(cc.Prefab)
    ], CoinEffect.prototype, "item", void 0);
    CoinEffect = __decorate([
        ccclass
    ], CoinEffect);
    return CoinEffect;
}(cc.Component));
exports.CoinEffect = CoinEffect;

cc._RF.pop();